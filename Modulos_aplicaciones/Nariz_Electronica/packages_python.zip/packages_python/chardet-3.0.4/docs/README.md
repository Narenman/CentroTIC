For users, docs are now available at https://chardet.readthedocs.io/.

For devs, you can edit the RST files in this directory.
